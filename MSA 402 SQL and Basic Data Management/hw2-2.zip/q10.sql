##Q10
SELECT DISTINCT id,name
FROM Student,Advisor
WHERE Student.id=Advisor.s_id

EXCEPT

SELECT Student.id,Student.name
FROM Student,Takes,Teaches,Advisor
WHERE
Student.id=Takes.id
AND Takes.class_id=Teaches.class_id
AND Takes.semester=Teaches.semester
AND Takes.year=Teaches.year
AND Teaches.id=Advisor.i_id
AND Takes.sec_id=Teaches.sec_id
AND Student.id=Advisor.s_id;
