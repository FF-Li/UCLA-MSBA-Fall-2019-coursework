##q2
SELECT name
FROM Student
WHERE tot_cred>60;
