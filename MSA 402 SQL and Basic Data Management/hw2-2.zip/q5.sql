##q5
SELECT Class.class_id,title
FROM Class,Takes
WHERE id=12345
AND Class.class_id=Takes.class_id;
