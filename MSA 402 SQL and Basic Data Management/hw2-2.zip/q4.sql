##q4
SELECT title
FROM Class
WHERE dept='Comp. Sci.'
AND credits=3;
