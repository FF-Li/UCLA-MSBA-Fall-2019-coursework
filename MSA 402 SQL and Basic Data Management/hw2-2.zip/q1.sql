##q1
SELECT name, salary
FROM Instructor
WHERE dept='Finance';
