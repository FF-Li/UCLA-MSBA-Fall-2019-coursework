##q8
SELECT Instructor.id,Instructor.name
FROM Instructor
WHERE Instructor.id
NOT IN (SELECT Teaches.id from Teaches);
