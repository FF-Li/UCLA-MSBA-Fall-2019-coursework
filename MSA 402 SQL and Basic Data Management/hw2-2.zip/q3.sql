##q3
SELECT title
FROM Class
WHERE class_id LIKE '%101%';
