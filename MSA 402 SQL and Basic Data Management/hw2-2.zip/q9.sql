##q9
SELECT name
FROM Student,Prereq,Takes
WHERE
Student.id=Takes.id
AND Prereq.class_id=Takes.class_id
AND (Prereq.prereq_id
NOT IN (SELECT Takes.class_id from Takes WHERE Student.id=Takes.id));
