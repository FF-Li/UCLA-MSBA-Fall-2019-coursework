##q6
SELECT DISTINCT name
FROM Student,Takes,Class
WHERE Class.dept='Comp. Sci.'
AND Class.class_id=Takes.class_id
AND Student.id=Takes.id;
